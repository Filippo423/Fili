<?php
    session_destroy();
    header("Location: http://localhost/login/login1.php");
?>