//TODO migliorare controlli pressione tasti


var v1 = '';
var v2 = '';
var operation;
var selected = 1;
//var res = document.getElementById('res');

function getRes(){return document.getElementById('res');}

function number(n){
    if(selected == 1){
        getRes().innerHTML = ''; 
        v1 = v1+n;
        getRes().innerHTML = v1;
    }else{
        getRes().innerHTML = '';
        v2 = v2+n;
        getRes().innerHTML = v2;
    }
}

function op(o){
    operation = o;
    selected = 2;
    getRes().innerHTML = o;
}

function equal(){
    if(v2 == '') return;
    v1 = parseFloat(v1, 10);
    v2 = parseFloat(v2, 10);
    switch(operation){
        case '+':
            getRes().innerHTML = v1 + v2;
            selected = 1;
        break;
        case '*':
            getRes().innerHTML = v1 * v2;
            selected = 1;
        break;
        case '-':
            getRes().innerHTML = v1 - v2;
            selected = 1;
        break;
        case '/':
            getRes().innerHTML = v1 / v2;
            selected = 1;
        break;
    }
    //il risultato diventa il primo operando dell'operazione successiva
    v1 = getRes().textContent;
    v2 = '';
}

function canc(){
    v1 = '';
    v2 = '';
    operation = '';
    selected = 1;
    getRes().innerHTML = "<br>";
}