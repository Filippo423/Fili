<html>
    <head>
        <title>CALCOLATRICE</title>
        <link rel="stylesheet" href="calc.css">
    </head>

    <body>
        <center>
            <div id="benvenuto">
                <h3>BENVENUTO <?php session_start(); echo $_SESSION["nomeutente"];?></h3>
                <p id="logout"><a href="http://localhost/login/logout.php"><b>LOGOUT</b></a></p>
            </div>
            <p id="res"><br></p>
            <table class="table">
    
                <tr>
                    <td>
                        <input class="number" id="7" type="button" value="7" onclick="number('7')">
                    </td>
                    <td>
                        <input class="number" id="8" type="button" value="8" onclick="number('8')">
                    </td>
                    <td>
                        <input class="number" id="9" type="button" value="9" onclick="number('9')">
                    </td>
                    <td>
                        <input class="op" id="+" type="button" value="+" onclick="op('+')">
                    </td>
                    <td>
                        <input class="op" id="-" type="button" value="-" onclick="op('-')">
                    </td>
                </tr>
    
                <tr>
                    <td>
                        <input class="number" id="4" type="button" value="4" onclick="number('4')">
                    </td>
                    <td>
                        <input class="number" id="5" type="button" value="5" onclick="number('5')">
                    </td>
                    <td>
                        <input class="number" id="6" type="button" value="6" onclick="number('6')">
                    </td>
                    <td>
                        <input class="op" id="*" type="button" value="*" onclick="op('*')">
                    </td>
                    <td>
                        <input class="op" id="/" type="button" value="/" onclick="op('/')">
                    </td>
                </tr>
    
                <tr>
                    <td>
                        <input class="number" id="1" type="button" value="1" onclick="number('1')">
                    </td>
                    <td>
                        <input class="number" id="2" type="button" value="2" onclick="number('2')">
                    </td>
                    <td>
                        <input class="number" id="3" type="button" value="3" onclick="number('3')">
                    </td>
                    <td>
                        <input class="eq" id="=" type="button" value="=" onclick="equal()">
                    </td>
                    <td>
                        <input class="canc" id="ce" type="button" value="C" onclick="canc()">
                    </td>
                </tr>
    
                <tr>
                    <td>
                        <input class="number" id="0" type="button" value="0" onclick="number('0')">
                    </td>
                    <td>
                        <input class="number" id="dot" type="button" value="." onclick="number('.')">
                    </td>
                </tr>
    
            </table>

            <script src="calc.js"></script>
            
        </center>
    
    </body>
</html>
