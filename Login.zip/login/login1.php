<?php
    session_start();

    if(isset($_POST['password']) && isset($_POST['nomeutente']) && strlen(trim($_POST['nomeutente'])) > 0 && strlen(trim($_POST['nomeutente'])) > 0){

        if($_POST['nomeutente'] != "admin"){
            $_POST["erroreNOME"] = "Non registrato";
            unset($_POST["errorePW"]);

        }else if($_POST['password'] != "admin"){
            $_POST["errorePW"] = "Password errata";
            unset($_POST["erroreNOME"]);

        }else{
            //unset($_POST["errorePW"]);
            //unset($_POST["erroreNOME"]);
            $_SESSION["nomeutente"] = $_POST["nomeutente"];
            header("Location: http://localhost/login/calcolatrice/calc.php");
        }
    }
?>

<html>
    <head>
        <title>LOGIN</title>
        <link rel="stylesheet" href="login.css">
    </head>

    <body>
        <div id="div_form">
            <form class="form" action="login1.php" method="POST">
                <div>
                    <p class="error"><?php echo $_POST["erroreNOME"] ?? "<br>"; ?></p>
                    <label for="nomeutente">NOME UTENTE</label>
                    <br><input autofocus="true" required="true" type="text" name="nomeutente" id="nomeutente" value='<?php echo $_POST["nomeutente"] ?? ""; ?>'>
                </div>
            
                <div>
                    <p class="error"><?php echo $_POST["errorePW"] ?? "<br>"; ?></p>
                    <label for="password">PASSWORD</label>
                    <br><input required="true" type="password" name="password" id="password">
                </div>

                <center><br><input id="enter" type="submit" value="LOGIN"></center>
            </form>
        </div>
        
    </body>
</html>
